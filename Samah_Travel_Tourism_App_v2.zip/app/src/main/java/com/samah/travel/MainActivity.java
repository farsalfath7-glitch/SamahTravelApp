package com.samah.travel;

import android.app.*;
import android.os.*;
import android.content.*;
import android.database.sqlite.*;
import android.database.*;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.provider.OpenableColumns;
import android.view.*;
import android.widget.*;
import java.util.*;

public class MainActivity extends Activity {
    final int NAVY=Color.rgb(7,26,56), GOLD=Color.rgb(217,166,46), WHITE=Color.WHITE, GREEN=Color.rgb(24,125,82);
    LinearLayout root, content;
    DB db;
    long selectedService=-1;
    Uri passportUri, paymentUri;

    TextView text(String s,int sp){
        TextView t=new TextView(this); t.setText(s); t.setTextSize(sp); t.setTextColor(NAVY);
        t.setPadding(20,14,20,14); t.setGravity(Gravity.RIGHT|Gravity.CENTER_VERTICAL); return t;
    }
    Button button(String s){
        Button b=new Button(this); b.setText(s); b.setTextSize(15); b.setTextColor(WHITE);
        b.setBackground(round(NAVY,18)); b.setAllCaps(false); return b;
    }
    GradientDrawable round(int c,int r){ GradientDrawable g=new GradientDrawable(); g.setColor(c); g.setCornerRadius(r); return g; }
    void shell(String title){
        root=new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL); root.setBackgroundColor(Color.rgb(247,248,250));
        LinearLayout bar=new LinearLayout(this); bar.setPadding(14,8,14,8); bar.setGravity(Gravity.CENTER); bar.setBackgroundColor(NAVY);
        TextView t=text(title,21); t.setTextColor(WHITE); t.setGravity(Gravity.CENTER); bar.addView(t,new LinearLayout.LayoutParams(-1,60));
        root.addView(bar);
        ScrollView sv=new ScrollView(this); content=new LinearLayout(this); content.setOrientation(LinearLayout.VERTICAL); content.setPadding(16,16,16,24); sv.addView(content);
        root.addView(sv,new LinearLayout.LayoutParams(-1,0,1)); setContentView(root);
    }
    @Override public void onCreate(Bundle b){super.onCreate(b); db=new DB(this); if(db.countServices()==0) db.seed(); login();}
    void login(){
        shell("وكالة سماح");
        TextView logo=text("وكالة سماح\nللسفر والسياحة\nوالحج والعمرة",28); logo.setTextColor(GOLD); logo.setGravity(Gravity.CENTER); content.addView(logo);
        content.addView(text("تأشيرات • سفر • سياحة • حج وعمرة",16));
        EditText u=new EditText(this); u.setHint("اسم المستخدم"); content.addView(u);
        EditText p=new EditText(this); p.setHint("كلمة المرور"); p.setInputType(129); content.addView(p);
        Button go=button("تسجيل الدخول"); go.setBackground(round(GOLD,18)); go.setTextColor(NAVY); content.addView(go);
        go.setOnClickListener(v->{ if(u.getText().toString().equals("admin")&&p.getText().toString().equals("1234")) home(); else Toast.makeText(this,"اسم المستخدم أو كلمة المرور غير صحيحة",Toast.LENGTH_SHORT).show();});
    }
    void home(){
        shell("الرئيسية");
        content.addView(text("مرحبًا بك 👋\nخدمات سفر وتأشيرات وحج وعمرة",22));
        Button c=button("🌍 الدول والخدمات"); content.addView(c); c.setOnClickListener(v->countries());
        Button o=button("📋 طلباتي"); content.addView(o); o.setOnClickListener(v->orders());
        Button a=button("⚙️ لوحة الإدارة"); content.addView(a); a.setOnClickListener(v->admin());
    }
    void countries(){
        shell("الدول والخدمات");
        Cursor c=db.countries();
        while(c.moveToNext()){
            final String country=c.getString(1);
            Button b=button("🌍 "+country); content.addView(b); b.setOnClickListener(v->country(country));
        }
        c.close();
        Button add=button("＋ إضافة دولة جديدة"); add.setBackground(round(GOLD,18)); add.setTextColor(NAVY); content.addView(add); add.setOnClickListener(v->addCountry());
    }
    void country(String country){
        shell(country);
        Cursor c=db.services(country);
        while(c.moveToNext()){
            final long id=c.getLong(0); final String name=c.getString(2), desc=c.getString(3), price=c.getString(4);
            LinearLayout card=new LinearLayout(this); card.setOrientation(LinearLayout.VERTICAL); card.setPadding(14,10,14,10); card.setBackground(round(WHITE,22));
            card.addView(text(name,19)); card.addView(text(desc,14)); TextView p=text("السعر: "+price,16); p.setTextColor(GOLD); card.addView(p);
            Button apply=button("تقديم طلب"); apply.setBackground(round(GOLD,18)); apply.setTextColor(NAVY); card.addView(apply); apply.setOnClickListener(v->apply(id));
            content.addView(card,new LinearLayout.LayoutParams(-1,-2));
        }
        c.close();
    }
    void apply(long serviceId){
        selectedService=serviceId; passportUri=null; paymentUri=null;
        String[] s=db.service(serviceId);
        shell("تقديم طلب");
        content.addView(text(s[0]+" — "+s[1]+"\nالسعر الحالي: "+s[3],19));
        EditText n=new EditText(this); n.setHint("الاسم الكامل"); content.addView(n);
        EditText ph=new EditText(this); ph.setHint("رقم الهاتف"); content.addView(ph);
        EditText pass=new EditText(this); pass.setHint("رقم جواز السفر"); content.addView(pass);
        Button doc=button("📷 اختيار صورة الجواز"); content.addView(doc);
        TextView docName=text("لم يتم اختيار ملف",13); content.addView(docName);
        doc.setOnClickListener(v->{Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT); i.setType("image/*"); i.addCategory(Intent.CATEGORY_OPENABLE); startActivityForResult(i,101);});
        Button pay=button("💳 اختيار إثبات الدفع"); content.addView(pay);
        TextView payName=text("لم يتم اختيار ملف",13); content.addView(payName);
        pay.setOnClickListener(v->{Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT); i.setType("*/*"); i.addCategory(Intent.CATEGORY_OPENABLE); startActivityForResult(i,102);});
        Button send=button("إرسال الطلب"); send.setBackground(round(GOLD,18)); send.setTextColor(NAVY); content.addView(send);
        send.setOnClickListener(v->{if(n.getText().length()==0||ph.getText().length()==0||pass.getText().length()==0){Toast.makeText(this,"أكمل البيانات الأساسية أولًا",Toast.LENGTH_SHORT).show();return;} long id=db.addOrder(serviceId,n.getText().toString(),ph.getText().toString(),pass.getText().toString(),passportUri==null?"":passportUri.toString(),paymentUri==null?"":paymentUri.toString()); confirm(id);});
    }
    @Override protected void onActivityResult(int r,int code,Intent data){super.onActivityResult(r,code,data); if(code==RESULT_OK&&data!=null){if(r==101) passportUri=data.getData(); if(r==102) paymentUri=data.getData(); Toast.makeText(this,"تم اختيار الملف",Toast.LENGTH_SHORT).show();}}
    void confirm(long id){
        shell("تم استلام الطلب");
        TextView ok=text("✓\nتم استلام طلبك بنجاح\n\nرقم الطلب: SM-"+String.format("%06d",id)+"\nالحالة: قيد المراجعة",24); ok.setGravity(Gravity.CENTER); ok.setTextColor(GREEN); content.addView(ok);
        Button b=button("متابعة الطلبات"); content.addView(b); b.setOnClickListener(v->orders());
    }
    void orders(){
        shell("طلباتي");
        Cursor c=db.orders();
        while(c.moveToNext()){
            String s="رقم الطلب: SM-"+String.format("%06d",c.getLong(0))+"\nالخدمة: "+c.getString(2)+"\nالعميل: "+c.getString(3)+"\nالحالة: "+c.getString(6);
            content.addView(text(s,17));
        } c.close();
    }
    void admin(){
        shell("لوحة الإدارة");
        content.addView(text("إدارة الدول والخدمات والأسعار والطلبات",21));
        Button addC=button("＋ إضافة دولة"); content.addView(addC); addC.setOnClickListener(v->addCountry());
        Button addS=button("＋ إضافة خدمة"); content.addView(addS); addS.setOnClickListener(v->addService());
        Cursor c=db.allServices();
        while(c.moveToNext()){
            final long id=c.getLong(0); String line=c.getString(1)+" — "+c.getString(2)+"\nالسعر: "+c.getString(4);
            LinearLayout row=new LinearLayout(this); row.setOrientation(LinearLayout.VERTICAL); row.setPadding(12,10,12,10); row.setBackground(round(WHITE,18)); row.addView(text(line,16));
            Button e=button("✏️ تعديل السعر"); row.addView(e); e.setOnClickListener(v->editPrice(id));
            Button d=button("🗑️ حذف الخدمة"); row.addView(d); d.setBackground(round(Color.rgb(170,45,45),18)); d.setOnClickListener(v->{db.deleteService(id);admin();});
            content.addView(row);
        } c.close();
        content.addView(text("طلبات العملاء",20));
        Cursor o=db.orders(); while(o.moveToNext()){
            final long id=o.getLong(0); content.addView(text("SM-"+String.format("%06d",id)+" | "+o.getString(2)+" | "+o.getString(6),16));
        } o.close();
    }
    void editPrice(long id){
        EditText e=new EditText(this); e.setHint("السعر الجديد"); e.setText(db.service(id)[3]);
        new AlertDialog.Builder(this).setTitle("تعديل السعر").setView(e).setPositiveButton("حفظ",(d,w)->{db.updatePrice(id,e.getText().toString());admin();}).setNegativeButton("إلغاء",null).show();
    }
    void addCountry(){
        EditText e=new EditText(this); e.setHint("اسم الدولة");
        new AlertDialog.Builder(this).setTitle("إضافة دولة").setView(e).setPositiveButton("إضافة",(d,w)->{String x=e.getText().toString().trim();if(!x.isEmpty())db.addCountry(x);admin();}).setNegativeButton("إلغاء",null).show();
    }
    void addService(){
        LinearLayout box=new LinearLayout(this); box.setOrientation(LinearLayout.VERTICAL);
        EditText c=new EditText(this); c.setHint("الدولة"); box.addView(c);
        EditText n=new EditText(this); n.setHint("اسم الخدمة"); box.addView(n);
        EditText de=new EditText(this); de.setHint("الوصف"); box.addView(de);
        EditText p=new EditText(this); p.setHint("السعر"); box.addView(p);
        new AlertDialog.Builder(this).setTitle("إضافة خدمة").setView(box).setPositiveButton("إضافة",(d,w)->{db.addService(c.getText().toString(),n.getText().toString(),de.getText().toString(),p.getText().toString());admin();}).setNegativeButton("إلغاء",null).show();
    }

    class DB extends SQLiteOpenHelper {
        DB(Context c){super(c,"samah.db",null,2);}
        public void onCreate(SQLiteDatabase x){x.execSQL("CREATE TABLE countries(id INTEGER PRIMARY KEY AUTOINCREMENT,name TEXT UNIQUE)");x.execSQL("CREATE TABLE services(id INTEGER PRIMARY KEY AUTOINCREMENT,country TEXT,name TEXT,description TEXT,price TEXT)");x.execSQL("CREATE TABLE orders(id INTEGER PRIMARY KEY AUTOINCREMENT,service_id INTEGER,service TEXT,customer TEXT,phone TEXT,passport TEXT,status TEXT,passport_uri TEXT,payment_uri TEXT)");}
        public void onUpgrade(SQLiteDatabase x,int a,int b){x.execSQL("DROP TABLE IF EXISTS orders");x.execSQL("DROP TABLE IF EXISTS services");x.execSQL("DROP TABLE IF EXISTS countries");onCreate(x);seed();}
        void seed(){String[] cs={"الإمارات","القاهرة","السعودية"};for(String c:cs)addCountry(c);addService("الإمارات","زيارة 3 شهور","زيارة لمدة 90 يوم","25,000");addService("الإمارات","إقامة كوادر","إقامة للعمل (كوادر)","18,000");addService("القاهرة","تأشيرة","تأشيرة دخول","يحدد لاحقًا");addService("القاهرة","موافقة أمنية","خدمة موافقة أمنية","يحدد لاحقًا");addService("السعودية","زيارة","تأشيرة زيارة","يحدد لاحقًا");addService("السعودية","عمرة","تأشيرة وخدمات العمرة","يحدد لاحقًا");}
        SQLiteDatabase w(){return getWritableDatabase();}
        void addCountry(String n){ContentValues v=new ContentValues();v.put("name",n);w().insertWithOnConflict("countries",null,v,SQLiteDatabase.CONFLICT_IGNORE);}
        void addService(String c,String n,String d,String p){ContentValues v=new ContentValues();v.put("country",c);v.put("name",n);v.put("description",d);v.put("price",p);w().insert("services",null,v);}
        Cursor countries(){return w().rawQuery("SELECT * FROM countries ORDER BY id",null);}
        Cursor services(String c){return w().rawQuery("SELECT * FROM services WHERE country=? ORDER BY id",new String[]{c});}
        Cursor allServices(){return w().rawQuery("SELECT * FROM services ORDER BY id",null);}
        int countServices(){Cursor c=w().rawQuery("SELECT COUNT(*) FROM services",null);c.moveToFirst();int n=c.getInt(0);c.close();return n;}
        String[] service(long id){Cursor c=w().rawQuery("SELECT country,name,description,price FROM services WHERE id=?",new String[]{""+id});c.moveToFirst();String[] a={c.getString(0),c.getString(1),c.getString(2),c.getString(3)};c.close();return a;}
        void updatePrice(long id,String p){ContentValues v=new ContentValues();v.put("price",p);w().update("services",v,"id=?",new String[]{""+id});}
        void deleteService(long id){w().delete("services","id=?",new String[]{""+id});}
        long addOrder(long sid,String name,String phone,String passport,String pu,String pay){String[] s=service(sid);ContentValues v=new ContentValues();v.put("service_id",sid);v.put("service",s[0]+" — "+s[1]);v.put("customer",name);v.put("phone",phone);v.put("passport",passport);v.put("status","قيد المراجعة");v.put("passport_uri",pu);v.put("payment_uri",pay);return w().insert("orders",null,v);}
        Cursor orders(){return w().rawQuery("SELECT * FROM orders ORDER BY id DESC",null);}
    }
}
