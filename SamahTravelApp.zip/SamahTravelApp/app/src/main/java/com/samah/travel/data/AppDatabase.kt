package com.samah.travel.data
import android.content.Context
import androidx.room.*
@Database(entities=[Order::class],version=1,exportSchema=false)
abstract class AppDatabase:RoomDatabase(){abstract fun orderDao():OrderDao
 companion object { @Volatile private var INSTANCE:AppDatabase?=null; fun get(c:Context):AppDatabase=INSTANCE?:synchronized(this){INSTANCE?:Room.databaseBuilder(c.applicationContext,AppDatabase::class.java,"samah_database").build().also{INSTANCE=it}}}}
