package com.samah.travel
import android.net.Uri
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.*
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.samah.travel.data.*
import kotlinx.coroutines.launch
class MainActivity:AppCompatActivity(){
 private val db by lazy{AppDatabase.get(this)}; private var passport:Uri?=null; private lateinit var content:LinearLayout
 private val picker=registerForActivityResult(ActivityResultContracts.GetContent()){passport=it}
 override fun onCreate(b:Bundle?){super.onCreate(b);home()}
 private fun root(t:String){val o=LinearLayout(this);o.orientation=LinearLayout.VERTICAL;o.setPadding(24,20,24,20);o.layoutDirection=View.LAYOUT_DIRECTION_RTL;val h=TextView(this);h.text=t;h.textSize=23f;h.gravity=Gravity.CENTER;o.addView(h);content=LinearLayout(this);content.orientation=LinearLayout.VERTICAL;content.layoutDirection=View.LAYOUT_DIRECTION_RTL;val s=ScrollView(this);s.addView(content);o.addView(s,LinearLayout.LayoutParams(-1,0,1f));setContentView(o)}
 private fun btn(t:String,a:()->Unit)=Button(this).apply{text=t;textSize=17f;setOnClickListener{a()}}
 private fun inp(h:String)=EditText(this).apply{hint=h;textSize=16f}
 private fun home(){root("وكالة سماح للسفر والسياحة والحج والعمرة");content.addView(TextView(this).apply{text="مرحبًا بكم في وكالة سماح";textSize=20f;gravity=Gravity.CENTER});content.addView(btn("إنشاء طلب جديد"){create()});content.addView(btn("متابعة طلباتي"){customer()});content.addView(btn("لوحة المسؤول"){admin()})}
 private fun create(){root("إنشاء طلب جديد");val n=inp("اسم العميل");val c=inp("الدولة");val p=inp("السعر");val e=inp("أوراق إضافية");val sp=Spinner(this);sp.adapter=ArrayAdapter(this,android.R.layout.simple_spinner_dropdown_item,listOf("تأشيرة سفر","سياحة","حج","عمرة","خدمة أخرى"));content.addView(n);content.addView(c);content.addView(sp);content.addView(p);content.addView(e);content.addView(btn("اختيار صورة الجواز"){picker.launch("image/*")});content.addView(btn("حفظ الطلب"){if(n.text.isBlank()||c.text.isBlank()){Toast.makeText(this,"أدخل اسم العميل والدولة",Toast.LENGTH_SHORT).show();return@btn};lifecycleScope.launch{db.orderDao().insert(Order(customerId=1,customerName=n.text.toString(),country=c.text.toString(),service=sp.selectedItem.toString(),price=p.text.toString(),paymentStatus="غير مدفوع",passportImage=passport?.toString(),extraDocuments=e.text.toString()));runOnUiThread{Toast.makeText(this@MainActivity,"تم حفظ الطلب",Toast.LENGTH_SHORT).show();customer()}}});content.addView(btn("رجوع"){home()})}
 private fun customer(){root("متابعة طلباتي");lifecycleScope.launch{db.orderDao().ordersForCustomer(1).collect{list->runOnUiThread{content.removeAllViews();if(list.isEmpty())content.addView(TextView(this@MainActivity).apply{text="لا توجد طلبات";textSize=18f});list.forEach{o->content.addView(TextView(this@MainActivity).apply{text="طلب #${o.id}\n${o.service}\nالحالة: ${o.status}";textSize=17f});content.addView(btn("التفاصيل"){details(o.id,false)})};content.addView(btn("طلب جديد"){create()});content.addView(btn("الرئيسية"){home()})}}}}
 private fun admin(){root("لوحة المسؤول");lifecycleScope.launch{db.orderDao().allOrders().collect{list->runOnUiThread{content.removeAllViews();list.forEach{o->content.addView(TextView(this@MainActivity).apply{text="طلب #${o.id} — ${o.customerName}\n${o.service} — ${o.status}";textSize=17f});content.addView(btn("تفاصيل"){details(o.id,true)})};content.addView(btn("الرئيسية"){home()})}}}}
 private fun details(id:Long,isAdmin:Boolean){root("تفاصيل الطلب");lifecycleScope.launch{val o=db.orderDao().getById(id)?:return@launch;runOnUiThread{content.addView(TextView(this@MainActivity).apply{text="رقم الطلب: ${o.id}\nالعميل: ${o.customerName}\nالدولة: ${o.country}\nالخدمة: ${o.service}\nالسعر: ${o.price}\nالدفع: ${o.paymentStatus}\nالجواز: ${if(o.passportImage!=null)"مرفق" else "غير مرفق"}\nالحالة: ${o.status}";textSize=18f});if(isAdmin){content.addView(btn("قيد المراجعة"){status(o,"قيد المراجعة")});content.addView(btn("تم التنفيذ"){status(o,"تم التنفيذ")});content.addView(btn("رجوع"){admin()})}else content.addView(btn("رجوع"){customer()})}}}
 private fun status(o:Order,s:String){lifecycleScope.launch{db.orderDao().update(o.copy(status=s));runOnUiThread{admin()}}}
}
