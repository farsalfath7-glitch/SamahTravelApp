package com.samah.travel.data
import androidx.room.Entity
import androidx.room.PrimaryKey
@Entity(tableName="orders")
data class Order(@PrimaryKey(autoGenerate=true) val id:Long=0,val customerId:Long,val customerName:String,val country:String,val service:String,val price:String,val paymentStatus:String,val passportImage:String?,val extraDocuments:String?,val createdAt:Long=System.currentTimeMillis(),val status:String="قيد المراجعة")
