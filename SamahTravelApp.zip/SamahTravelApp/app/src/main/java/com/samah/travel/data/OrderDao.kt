package com.samah.travel.data
import androidx.room.*
import kotlinx.coroutines.flow.Flow
@Dao interface OrderDao { @Insert suspend fun insert(order:Order):Long; @Query("SELECT * FROM orders WHERE customerId=:customerId ORDER BY createdAt DESC") fun ordersForCustomer(customerId:Long):Flow<List<Order>>; @Query("SELECT * FROM orders ORDER BY createdAt DESC") fun allOrders():Flow<List<Order>>; @Query("SELECT * FROM orders WHERE id=:id LIMIT 1") suspend fun getById(id:Long):Order?; @Update suspend fun update(order:Order) }
